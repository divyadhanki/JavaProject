package org.techhub.clientapp;

import java.util.Scanner;

import org.techhub.dashboard.AdminDashBoard;
import org.techhub.dashboard.UserDashBoard;
import org.techhub.model.LoginModel;
import org.techhub.service.ValidateUserService;
import org.techhub.service.ValidateUserServiceImpl;

public class ClientApplication {

    public static String logUsername;

    static ValidateUserService validateUserService = new ValidateUserServiceImpl();

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        do {

            System.out.println("Welcome In House Price Prediction System");
            System.out.println("1: Login");
            System.out.println("2: Register as User");
            System.out.println("3: Exit");
            System.out.println("Enter your choice");

            int choice = sc.nextInt();

            switch (choice) {

            case 1:

                System.out.println("Enter username and password");

                sc.nextLine();   // clear buffer

                String username = sc.nextLine();
                String password = sc.nextLine();

                LoginModel model = new LoginModel();

                model.setUsername(username);
                model.setPassword(password);

                model = validateUserService.validateUser(model);

                if (model != null) {

                    if (model.getUsertype().equals("admin")) {

                        logUsername = model.getUsername();

                        AdminDashBoard dashBoard = new AdminDashBoard();

                    } else {

                        UserDashBoard ud = new UserDashBoard();

                    }

                } else {

                    System.out.println("Invalid username and password");

                }

                break;

            case 2:

                System.out.println("User Registration Feature Coming Soon...");

                break;

            case 3:

                System.out.println("Thank You For Using System");

                System.exit(0);

                break;

            default:

                System.out.println("Wrong choice");

            }

        } while (true);

    }
}