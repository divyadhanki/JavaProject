package org.techhub.dashboard;

import java.util.*;


import org.techhub.clientapp.ClientApplication;
import org.techhub.model.CityModel;
import org.techhub.model.HouseModel;
import org.techhub.model.LocModel;
import org.techhub.model.StateModel;
import org.techhub.service.CityService;
import org.techhub.service.CityServiceImpl;
import org.techhub.service.HouseServiceImpl;
import org.techhub.service.LocServiceImpl;
import org.techhub.service.LocationService;
import org.techhub.service.StateService;
import org.techhub.service.StateServiceImpl;
import org.techhub.service.HouseService; 

public class AdminDashBoard {
	StateService stService = new StateServiceImpl();
	CityService ctService = new CityServiceImpl();
	LocationService locService = new LocServiceImpl();
	HouseService houseService=new HouseServiceImpl();

	public AdminDashBoard() {
		do {
			System.out.println("Welcome Admin :" + ClientApplication.logUsername);
			System.out.println("\n----------------------------------------------\n");
			System.out.println("1: State Master");
			System.out.println("2: City Master");
			System.out.println("3: Location Master");
			System.out.println("4: House Master");
			System.out.println("5: House Details");
			System.out.println("6: House Report");
			System.out.println("7 : Exit ");
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Your Choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("\t 1: Add New State");
				System.out.println("\t 2: View All State");
				System.out.println("\t 3: Delete State");
				System.out.println("\t 4: update State");
				System.out.println("\tEnter your choice");
				choice = sc.nextInt();
				sc.nextLine();

				switch (choice) {

				case 1:

					System.out.println("\tEnter State Name");
					String statename = sc.nextLine();
					StateModel sm = new StateModel();
					sm.setStateName(statename);
					boolean b = stService.isAddNewState(sm);
					if (b) {
						System.out.println("State Added Successfully");
					} else {
						System.out.println("State not Added");
					}
					break;
				case 2:
					List<StateModel> stateList = stService.getAllState();
					if (stateList.size() > 0) {
						System.out.println("StateId\t\tStateName");
						System.out.println("------------------------------------\n");
						for (StateModel model : stateList) {
							System.out.println(model.getStateId() + "\t\t" + model.getStateName());
						}
					} else {
						System.out.println("State not found");
					}

					break;
				case 3:
					stateList = stService.getAllState();
					if (stateList.size() > 0) {
						System.out.println("StateId\t\tStateName");
						System.out.println("------------------------------------\n");
						for (StateModel model : stateList) {
							System.out.println(model.getStateId() + "\t\t" + model.getStateName());
						}
						System.out.println("enter the stat id for delete");
						int stateid = sc.nextInt();
						boolean result = stService.isDeleteState(stateid);
						if (result) {
							System.out.println("State deleted Successfully");
						} else {
							System.out.println("some problem");
						}
					} else {
						System.out.println("State not found");
					}
					break;
				case 4:
					stateList = stService.getAllState();

					for (StateModel model : stateList) {
						System.out.println(model.getStateId() + "\t" + model.getStateName());
					}

					System.out.println("Enter State Id to Update");
					int stateId = sc.nextInt();
					sc.nextLine();

					System.out.println("Enter New State Name");
					String stateName = sc.nextLine();

					StateModel smodel = new StateModel();
					smodel.setStateId(stateId);
					smodel.setStateName(stateName);

					boolean res = stService.isUpdateState(smodel);

					if (res) {
						System.out.println("State Updated Successfully");
					} else {
						System.out.println("State Not Updated");
					}

					break;

				}

				break;

			case 2:
				System.out.println("\t 1: Add New City");
				System.out.println("\t 2: View All City by  State name");
				System.out.println("\t 3: Delete City");
				System.out.println("\t 4: update City");
				System.out.println("\tEnter your choice");
				choice = sc.nextInt();
				sc.nextLine();
				switch (choice) {
				case 1:
					List<StateModel> stateList = stService.getAllState();
					if (stateList.size() > 0) {
						System.out.println("StateId\t\tStateName");
						System.out.println("------------------------------------\n");
						for (StateModel model : stateList) {
							System.out.println(model.getStateId() + "\t\t" + model.getStateName());
						}
						System.out.println("------------------------------------\n");
						System.out.println("Enter City Name");
						String cityName = sc.nextLine();
						System.out.println(" Enter state ID");
						int stateid = sc.nextInt();
						CityModel ctmodel = new CityModel();
						ctmodel.setCityName(cityName);
						ctmodel.setStateId(stateid);
						boolean b = ctService.isAddNewCity(ctmodel);
						if (b) {
							System.out.println("city  added sucessfully");
						} else {
							System.out.println("city not added ");
						}
					} else {
						System.out.println("State not found");
					}
					break;
				case 2:
					List<CityModel> cityList = ctService.getAllCitiesWithStates();
					System.out.println("City Name \t\t\t State Name");
					if (cityList != null) {
						for (CityModel cm : cityList) {
							System.out.println(cm.getCityName() + " \t\t\t" + cm.getStateName());

						}
					} else {
						System.out.println("No city data Found ");
					}
					break;
				case 3:

					cityList = ctService.getAllCitiesWithStates();

					if (cityList != null) {

						System.out.println("CityId\t\tCityName\t\tStateName");
						System.out.println("------------------------------------------------");

						for (CityModel cm : cityList) {

							System.out.println(cm.getCityId() + "\t\t" + cm.getCityName() + "\t\t" + cm.getStateName());

						}

						System.out.println("Enter City Id to Delete");

						int cityId = sc.nextInt();

						boolean result = ctService.isDeleteCity(cityId);

						if (result) {

							System.out.println("City Deleted Successfully");

						} else {

							System.out.println("City Not Deleted");

						}

					} else {

						System.out.println("No City Data Found");

					}
					break;
				case 4:

					cityList = ctService.getAllCitiesWithStates();

					if (cityList != null) {

						System.out.println("CityId\t\tCityName\t\tStateName");

						for (CityModel cm : cityList) {

							System.out.println(cm.getCityId() + "\t\t" + cm.getCityName() + "\t\t" + cm.getStateName());

						}

						System.out.println("Enter City Id to Update");

						int cityId = sc.nextInt();
						sc.nextLine();

						System.out.println("Enter New City Name");

						String cityName = sc.nextLine();

						System.out.println("Enter New State Id");

						int stateId = sc.nextInt();

						CityModel model = new CityModel();

						model.setCityId(cityId);
						model.setCityName(cityName);
						model.setStateId(stateId);

						boolean result = ctService.isUpdateCity(model);

						if (result) {

							System.out.println("City Updated Successfully");

						} else {

							System.out.println("City Not Updated");

						}

					} else {

						System.out.println("No City Found");

					}

					break;
				case 5:
					System.exit(0);
				}
				break;
			case 3:
				System.out.println("\t 1: Add New loacation");
				System.out.println("\t 2: View All location by city");
				System.out.println("\t 3: Delete location");
				System.out.println("\t 4: update location");
				System.out.println("\tEnter your choice");
				choice = sc.nextInt();
				sc.nextLine();
				switch (choice) {
				case 1:
					List<CityModel> cityList = ctService.getAllCitiesWithStates();
					System.out.println(" cityId\t\t\t City Name \t\t\t State Name");
					if (cityList != null) {
						for (CityModel cm : cityList) {
							System.out.println(cm.getCityId() + "\t\t" + cm.getCityName() + " \t\t" + cm.getStateName());

						}
						
						System.out.println("Enter Location Name");
						String locName = sc.nextLine();
						System.out.println("Enter city Id");
						int cityId = sc.nextInt();
						LocModel lm = new LocModel();
						lm.setLocName(locName);
						lm.setCityId(cityId);
						boolean b = locService.isAddNewLocation(lm);
						if (b) {
							System.out.println("new location added successfully...");
						} else {
							System.out.println("location not added ");
						}

					} else {
						System.out.println("No city data Found ");
					}
					break;
				case 2:
				 cityList = ctService.getAllCitiesWithStates();

				    if(cityList != null) {

				        System.out.println("CityId\tCityName\tStateName");

				        for(CityModel cm : cityList) {

				            System.out.println(cm.getCityId()+"\t"+cm.getCityName()+"\t"+cm.getStateName());

				        }

				        System.out.println("Enter City Id");

				        int cityId = sc.nextInt();

				        List<LocModel> locList = locService.getLocationByCity(cityId);

				        if(locList != null) {

				            System.out.println("LocationId\tLocationName");

				            for(LocModel lm : locList) {

				                System.out.println(lm.getLocId()+"\t"+lm.getLocName());

				            }

				        }
				        else {

				            System.out.println("No Location Found");

				        }

				    }

					break;
				case 3:

				     cityList = ctService.getAllCitiesWithStates();

				    if(cityList != null) {

				        System.out.println("CityId\tCityName\tStateName");

				        for(CityModel cm : cityList) {

				            System.out.println(cm.getCityId()+"\t"+cm.getCityName()+"\t"+cm.getStateName());

				        }

				        System.out.println("Enter City Id");

				        int cityId = sc.nextInt();

				        List<LocModel> locList = locService.getLocationByCity(cityId);

				        if(locList != null) {

				            System.out.println("LocId\tLocationName");

				            for(LocModel lm : locList) {

				                System.out.println(lm.getLocId()+"\t"+lm.getLocName());

				            }

				            System.out.println("Enter Location Id to Delete");

				            int locId = sc.nextInt();

				            boolean result = locService.isDeleteLocation(locId);

				            if(result) {

				                System.out.println("Location Deleted Successfully");

				            }
				            else {

				                System.out.println("Location Not Deleted");

				            }

				        }
				        else {

				            System.out.println("No Location Found");

				        }

				    }
					break;
				case 4:
					  cityList = ctService.getAllCitiesWithStates();

					    if(cityList != null) {

					        System.out.println("CityId\tCityName\tStateName");

					        for(CityModel cm : cityList) {

					            System.out.println(cm.getCityId()+"\t"+cm.getCityName()+"\t"+cm.getStateName());

					        }

					        System.out.println("Enter City Id");

					        int cityId = sc.nextInt();

					        List<LocModel> locList = locService.getLocationByCity(cityId);

					        if(locList != null) {

					            System.out.println("LocId\tLocationName");

					            for(LocModel lm : locList) {

					                System.out.println(lm.getLocId()+"\t"+lm.getLocName());

					            }

					            System.out.println("Enter Location Id to Update");

					            int locId = sc.nextInt();
					            sc.nextLine();

					            System.out.println("Enter New Location Name");

					            String locName = sc.nextLine();

					            System.out.println("Enter New City Id");

					            int newCityId = sc.nextInt();

					            LocModel lm = new LocModel();

					            lm.setLocId(locId);
					            lm.setLocName(locName);
					            lm.setCityId(newCityId);

					            boolean result = locService.isUpdateLocation(lm);

					            if(result) {

					                System.out.println("Location Updated Successfully");

					            }
					            else {

					                System.out.println("Location Not Updated");

					            }

					        }
					        else {

					            System.out.println("No Location Found");

					        }

					    }
					break;
				}
				
				break;
				
			case 4:
				System.out.println("1: Add House");
			    System.out.println("2: Delete House");
			    System.out.println("3: Update House");
			    System.out.println("Enter Your Choice");

			    int hchoice = sc.nextInt();

			    switch(hchoice) {

			    case 1:
			        // INSERT HOUSE
			        List<LocModel> LocList = this.houseService.getAllLocations();

			        if(LocList.size() > 0) {

			            System.out.println("LocId\tLocation\tCity\tState");
			            System.out.println("========================================");

			            for(LocModel lm : LocList) {
			                System.out.println(lm.getLocId()+"\t"+lm.getLocName()+"\t"+lm.getCityName()+"\t"+lm.getStateName());
			            }

			            sc.nextLine();
			            System.out.println("Enter House Name:");
			            String hname = sc.nextLine();

			            System.out.println("Enter House Age:");
			            int age = sc.nextInt();

			            System.out.println("Enter Area in Square Feet:");
			            int asfeet = sc.nextInt();

			            System.out.println("Enter Number of Bathrooms:");
			            int nbath = sc.nextInt();

			            System.out.println("Enter Number of Bedrooms:");
			            int nbed = sc.nextInt();

			            System.out.println("Enter Location Id:");
			            int locid = sc.nextInt();

			            HouseModel model = new HouseModel();

			            model.setHname(hname);
			            model.setAge(age);
			            model.setAsfeet(asfeet);
			            model.setNbath(nbath);
			            model.setNbed(nbed);
			            model.setLocid(locid);

			            boolean b = houseService.isAddNewHouse(model);

			            if(b)
			                System.out.println("House Added Successfully");
			            else
			                System.out.println("House Not Added");

			        }
			        break;

			    case 2:
			        // DELETE HOUSE
			    	List<HouseModel> houseList = houseService.getAllHouses();

	                System.out.println("House\tAge\tSqFeet\tBath\tBed\tState\tCity\tLocation");

	                for (HouseModel model : houseList) {

	                    System.out.println(model.getHname() + "\t" + model.getAge() + "\t" + model.getAsfeet() + "\t"
	                            + model.getNbath() + "\t" + model.getNbed() + "\t" + model.getStatename() + "\t"
	                            + model.getCityName() + "\t" + model.getLocationName());

	                }
			        System.out.println("Enter House Id to Delete:");
			        int hid = sc.nextInt();

			        boolean d = houseService.isDeleteHouse(hid);

			        if(d)
			            System.out.println("House Deleted Successfully");
			        else
			            System.out.println("House Not Deleted");

			        break;

			    case 3:
			        // UPDATE HOUSE
			     
			    	 houseList = houseService.getAllHouses();

	                System.out.println("House\tAge\tSqFeet\tBath\tBed\tState\tCity\tLocation");

	                for (HouseModel model : houseList) {

	                    System.out.println(model.getHname() + "\t" + model.getAge() + "\t" + model.getAsfeet() + "\t"
	                            + model.getNbath() + "\t" + model.getNbed() + "\t" + model.getStatename() + "\t"
	                            + model.getCityName() + "\t" + model.getLocationName());

	                }
			        System.out.println("Enter House Id to Update:");
			        int uid = sc.nextInt();

			        sc.nextLine();
			        System.out.println("Enter New House Name:");
			        String newName = sc.nextLine();

			        HouseModel umodel = new HouseModel();
			        umodel.setHid(uid);
			        umodel.setHname(newName);

			        boolean u = houseService.isUpdateHouse(umodel);

			        if(u)
			            System.out.println("House Updated Successfully");
			        else
			            System.out.println("House Not Updated");

			        break;
			    }

				break;
			case 5:
				List<HouseModel> houseList = houseService.getAllHouses();

                System.out.println("House\tAge\tSqFeet\tBath\tBed\tState\tCity\tLocation");

                for (HouseModel model : houseList) {

                    System.out.println(model.getHname() + "\t" + model.getAge() + "\t" + model.getAsfeet() + "\t"
                            + model.getNbath() + "\t" + model.getNbed() + "\t" + model.getStatename() + "\t"
                            + model.getCityName() + "\t" + model.getLocationName());

                }

				break;
			case 6:
				 System.out.println("1. Count State Wise House");
				    System.out.println("2. Count State Wise City");
				    System.out.println("3. Count State Wise Location");
				    System.out.println("4. Count City Wise Location");
				    System.out.println("5. Count City Wise House");
				    System.out.println("6. Count Location Wise House");
				    System.out.println("7. Search House By City");
				    System.out.println("8. Search House By Location");
				    System.out.println("9. Count Area Wise House");

				    System.out.println("Enter Report Choice:");
				    int reportChoice = sc.nextInt();
				    sc.nextLine();

				    switch(reportChoice)
				    {

				    case 1:
				        houseService.countStateWiseHouse();
				        break;

				    case 2:
				        houseService.countStateWiseCity();
				        break;

				    case 3:
				        houseService.countStateWiseLocation();
				        break;

				    case 4:
				        houseService.countCityWiseLocation();
				        break;

				    case 5:
				        houseService.countCityWiseHouse();
				        break;

				    case 6:
				        houseService.countLocationWiseHouse();
				        break;

				    case 7:

				        System.out.println("Enter City Name:");
				        String cityName = sc.nextLine();

				        houseService.searchHouseByCity(cityName);

				        break;

				    case 8:

				        System.out.println("Enter Location Name:");
				        String locationName = sc.nextLine();

				        houseService.searchHouseByLocation(locationName);

				        break;

				    case 9:

				        houseService.countAreaWiseHouse();

				        break;

				    default:
				        System.out.println("Invalid Report Choice");

				    }
				break;
			case 7:
				System.exit(0);
			default:
				System.out.println("Wrong Choice");

			}

		} while (true);
	}

}