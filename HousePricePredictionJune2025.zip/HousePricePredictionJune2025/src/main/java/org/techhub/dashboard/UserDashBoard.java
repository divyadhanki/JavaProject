package org.techhub.dashboard;

import java.util.List;
import java.util.Scanner;

import org.techhub.model.CityModel;
import org.techhub.model.LocModel;
import org.techhub.model.StateModel;

import org.techhub.service.CityService;
import org.techhub.service.CityServiceImpl;
import org.techhub.service.HouseService;
import org.techhub.service.HouseServiceImpl;
import org.techhub.service.StateService;
import org.techhub.service.StateServiceImpl;
import org.techhub.service.LocationService;
import org.techhub.service.LocServiceImpl;

public class UserDashBoard {

    StateService stateService = new StateServiceImpl();
    CityService cityService = new CityServiceImpl();
    LocationService locService = new LocServiceImpl();
    HouseService houseService = new HouseServiceImpl();

    public UserDashBoard() {

        Scanner sc = new Scanner(System.in);

        do {

            System.out.println("\n1: Get Prediction");
            System.out.println("Enter your choice");

            int choice = sc.nextInt();

            switch(choice) {

            case 1:

                System.out.println("\nSelect State Id");

                List<StateModel> stateList = stateService.getAllState();

                for(StateModel sm : stateList) {
                    System.out.println(sm.getStateId()+"\t"+sm.getStateName());
                }

                System.out.println("Enter State Id:");
                int stateId = sc.nextInt();

                List<CityModel> cityList = cityService.getCityListByStateId(stateId);

                System.out.println("\nSelect City Id");

                for(CityModel cm : cityList) {
                    System.out.println(cm.getCityId()+"\t"+cm.getCityName());
                }

                System.out.println("Enter City Id:");
                int cityId = sc.nextInt();

                System.out.println("\nSelect Location Id");

                List<LocModel> locList = locService.getLocationByCityId(cityId);

                for(LocModel lm : locList) {
                    System.out.println(lm.getLocId()+"\t"+lm.getLocName());
                }
                System.out.println("Enter Location Id:");
                int locId = sc.nextInt();

                houseService.getSquareFeetAreas(locId);
                break;

            default:
                System.out.println("Wrong Choice");

            }

        } while(true);
    }
}