package org.techhub.repository;

import java.util.ArrayList;
import java.util.List;

import org.techhub.dbconfig.DBConfig;
import org.techhub.model.HouseModel;
import org.techhub.model.LocModel;

public class LocRepositoryImpl extends DBConfig implements LocRepository{

	@Override
	public boolean isAddNewLocation(LocModel model) {
		try {
			stmt=conn.prepareStatement("insert into location values('0',?,?)");
			stmt.setString(1, model.getLocName());
			stmt.setInt(2,model.getCityId());
			int value = stmt.executeUpdate();
			return value>0?true:false;
		}
		catch(Exception ex) {
			System.out.println("Error is "+ ex);
			return false;
		}
		
	}
	public List<LocModel> getLocationByCity(int cityId) {

	    List<LocModel> locList = new ArrayList<>();

	    try {

	        stmt = conn.prepareStatement(
	        "select locid, locname from location where cid=?");

	        stmt.setInt(1, cityId);

	        rs = stmt.executeQuery();

	        while(rs.next()) {

	            LocModel lm = new LocModel();

	            lm.setLocId(rs.getInt(1));
	            lm.setLocName(rs.getString(2));

	            locList.add(lm);
	        }

	        return locList.size() > 0 ? locList : null;

	    }
	    catch(Exception ex) {

	        System.out.println("Error is " + ex);
	        return null;

	    }
	}
	@Override
	public boolean isDeleteLocation(int locId) {

	    try {

	        stmt = conn.prepareStatement("delete from location where locid=?");

	        stmt.setInt(1, locId);

	        int value = stmt.executeUpdate();

	        return value > 0 ? true : false;

	    }
	    catch(Exception ex) {

	        System.out.println("Error is " + ex);
	        return false;

	    }
	}
	public boolean isUpdateLocation(LocModel model) {

	    try {

	        stmt = conn.prepareStatement(
	        "update location set locname=?, cid=? where locid=?");

	        stmt.setString(1, model.getLocName());
	        stmt.setInt(2, model.getCityId());
	        stmt.setInt(3, model.getLocId());

	        int value = stmt.executeUpdate();

	        return value > 0 ? true : false;

	    }
	    catch(Exception ex) {

	        System.out.println("Error is " + ex);
	        return false;

	    }
	}
	@Override
	public List<LocModel> getLocationByCityId(int cityId) {
	    List<LocModel> locList = new ArrayList<>();

	    try {

	        stmt = conn.prepareStatement(
	        "select locid, locname from location where cid=?");

	        stmt.setInt(1, cityId);

	        rs = stmt.executeQuery();

	        while(rs.next()) {

	            LocModel model = new LocModel();

	            model.setLocId(rs.getInt(1));
	            model.setLocName(rs.getString(2));

	            locList.add(model);
	        }

	    } catch(Exception ex) {

	        System.out.println("Error is " + ex);

	    }

	    return locList;

	}
	
}