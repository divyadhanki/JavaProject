package org.techhub.repository;

import java.util.List;

import org.techhub.model.HouseModel;
import org.techhub.model.LocModel;

public interface HouseRepository {
	public boolean isAddNewHouse(HouseModel model);
	public List<LocModel> getAllLocations();
	public List<HouseModel> getAllHouses();
	boolean isDeleteHouse(int hid);
	 boolean isUpdateHouse(HouseModel model);
	 void countStateWiseHouse();
	 void countStateWiseCity();
	 void countStateWiseLocation();
	 void countCityWiseLocation();
	 void countCityWiseHouse();
	 void countLocationWiseHouse();
	 void searchHouseByCity(String cityName);
	 void searchHouseByLocation(String locationName);
	 void countAreaWiseHouse();
	
	 List<Integer[]> getSquareFeetAreas(int locId);
	 int getMinOfXByLocId(int locId);
	 int getMinOfYByLocId(int locId);
	

}
