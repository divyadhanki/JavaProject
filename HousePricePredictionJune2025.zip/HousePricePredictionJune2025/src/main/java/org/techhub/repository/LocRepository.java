package org.techhub.repository;

import java.util.List;

import org.techhub.model.HouseModel;
import org.techhub.model.LocModel;

public interface LocRepository {
	boolean isAddNewLocation(LocModel model);
	List<LocModel> getLocationByCity(int cityId);
	boolean isDeleteLocation(int locId);
	 boolean isUpdateLocation(LocModel model);
	 public List<LocModel> getLocationByCityId(int cityId);
	 

}
