package org.techhub.repository;

import java.util.ArrayList;
import java.util.List;

import org.techhub.dbconfig.DBConfig;
import org.techhub.model.CityModel;

public class CityRepositoryImpl extends DBConfig implements CityRepository {

    List<CityModel> cityList;

    @Override
    public boolean isAddNewCity(CityModel model) {

        try {

            stmt = conn.prepareStatement(
            "insert into city(cityname,sid) values(?,?)");

            stmt.setString(1, model.getCityName());
            stmt.setInt(2, model.getStateId());

            int value = stmt.executeUpdate();

            return value > 0;

        } catch(Exception ex) {

            System.out.println("Error is " + ex);
            return false;
        }
    }

    @Override
    public List<CityModel> getAllCitiesWithStates() {

        try {

            cityList = new ArrayList<>();

            stmt = conn.prepareStatement(
            "select s.statename, c.cityname, c.cid from city c join state s on c.sid=s.sid");

            rs = stmt.executeQuery();

            while(rs.next()) {

                CityModel ct = new CityModel();

                ct.setStateName(rs.getString(1));
                ct.setCityName(rs.getString(2));
                ct.setCityId(rs.getInt(3));

                cityList.add(ct);
            }

            return cityList.size() > 0 ? cityList : null;

        } catch(Exception ex) {

            System.out.println("Error is " + ex);
            return null;
        }
    }

    @Override
    public boolean isDeleteCity(int cityId) {

        try {

            stmt = conn.prepareStatement(
            "delete from city where cid=?");

            stmt.setInt(1, cityId);

            int value = stmt.executeUpdate();

            return value > 0;

        } catch(Exception ex) {

            System.out.println("Error is " + ex);
            return false;
        }
    }

    @Override
    public boolean isUpdateCity(CityModel model) {

        try {

            stmt = conn.prepareStatement(
            "update city set cityname=?, sid=? where cid=?");

            stmt.setString(1, model.getCityName());
            stmt.setInt(2, model.getStateId());
            stmt.setInt(3, model.getCityId());

            int value = stmt.executeUpdate();

            return value > 0;

        } catch(Exception ex) {

            System.out.println("Error is " + ex);
            return false;
        }
    }

    @Override
    public List<CityModel> getCityListByStateId(int stateId) {

        List<CityModel> cityList = new ArrayList<>();

        try {

            stmt = conn.prepareStatement(
            "select cid, cityname from city where sid=?");

            stmt.setInt(1, stateId);

            rs = stmt.executeQuery();

            while(rs.next()) {

                CityModel model = new CityModel();

                model.setCityId(rs.getInt(1));
                model.setCityName(rs.getString(2));

                cityList.add(model);
            }

        } catch(Exception ex) {

            System.out.println("Error is " + ex);
        }

        return cityList;
    }
}