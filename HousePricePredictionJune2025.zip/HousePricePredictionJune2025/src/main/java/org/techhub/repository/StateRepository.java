package org.techhub.repository;

import java.util.List;

import org.techhub.model.StateModel;

public interface StateRepository {
	
	public boolean isAddState(StateModel state);
	public List<StateModel> getAllState();
	public boolean isDeleteState(int stateId);
	public boolean isUpdateState(StateModel model);
}
