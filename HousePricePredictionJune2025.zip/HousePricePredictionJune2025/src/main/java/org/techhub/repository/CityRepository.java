package org.techhub.repository;

import java.util.List;
import java.util.*;


import org.techhub.model.CityModel;

public interface CityRepository {
	public boolean isAddNewCity(CityModel model);
	public List<CityModel> getAllCitiesWithStates();
	boolean isDeleteCity(int cityId);
	boolean isUpdateCity(CityModel model);
	public List<CityModel> getCityListByStateId(int stateId);
	

}
