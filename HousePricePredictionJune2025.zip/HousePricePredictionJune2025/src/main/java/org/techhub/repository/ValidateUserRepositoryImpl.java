package org.techhub.repository;

import org.techhub.dbconfig.DBConfig;
import org.techhub.model.LoginModel;

public class ValidateUserRepositoryImpl extends DBConfig implements ValidateUserRepository {

	@Override
	public LoginModel validateUser(LoginModel model) {
		try {
			stmt = conn.prepareStatement("select *from user where username=? and password=?");
			stmt.setString(1, model.getUsername());
			stmt.setString(2, model.getPassword());
			rs = stmt.executeQuery();
			if (rs.next()) {
				model.setUsertype(rs.getString(4));
				model.setUserid(rs.getInt(1));
			}
			return model;
		} catch (Exception ex) {
			return null;
		}

	}

}