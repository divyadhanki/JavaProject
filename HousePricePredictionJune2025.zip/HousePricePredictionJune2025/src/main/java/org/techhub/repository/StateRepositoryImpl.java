package org.techhub.repository;

import java.util.ArrayList;
import java.util.List;

import org.techhub.dbconfig.DBConfig;
import org.techhub.model.StateModel;

public class StateRepositoryImpl extends DBConfig implements StateRepository{

	private static final String StateModel = null;
	List <StateModel> stateList;
	@Override
	public boolean isAddState(StateModel state) {
		
		try {
			stmt =conn.prepareStatement("insert into State values('0',? ) ");
			stmt.setString(1, state.getStateName());
			int value=stmt.executeUpdate();
			return value>0? true:false;
		}
		catch(Exception ex) {
			System.out.println("Error is " + ex);
			return false;
		}
		
	}

	@Override
	public List<StateModel> getAllState() {
		try {
			stateList=new ArrayList<StateModel>();
		
			stmt=conn.prepareStatement("Select * from state  ");
		    rs= stmt.executeQuery();
		    while(rs.next()){
		    	StateModel sm = new StateModel(rs.getInt(1), rs.getString(2));
		    	stateList.add(sm);
		    }
			return stateList;
		}
		catch(Exception ex){
			System.out.println("Error is "+ex);
			return null;
			
			
		}
		
	}

	@Override
	public boolean isDeleteState(int stateId) {
		try {
	   stmt=conn.prepareStatement("delete from state where sid=?");
	   stmt.setInt(1, stateId);
	   int  value=stmt.executeUpdate();
	   if(value>0) {
		   return true;
	   }
	   else {
		   return false;
		   
	   }
		}
		catch(Exception ex) {
			return false;
		}
		
	}
	@Override
	public boolean isUpdateState(StateModel model) {

		try {

			stmt = conn.prepareStatement(
			"update state set statename=? where sid=?");

			stmt.setString(1, model.getStateName());
			stmt.setInt(2, model.getStateId());

			int value = stmt.executeUpdate();

			if(value > 0){
				return true;
			}

		}
		catch(Exception ex){
			System.out.println("Error is " + ex);
		}

		return false;
	}
	

}
