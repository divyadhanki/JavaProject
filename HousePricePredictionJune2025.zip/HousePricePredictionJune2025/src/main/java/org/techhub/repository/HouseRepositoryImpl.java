package org.techhub.repository;

import java.util.ArrayList;
import java.util.List;

import org.techhub.dbconfig.DBConfig;
import org.techhub.model.HouseModel;
import org.techhub.model.LocModel;

public class HouseRepositoryImpl extends DBConfig implements HouseRepository {
	List<LocModel> locList;
	@Override
	public boolean isAddNewHouse(HouseModel model) {
	    try {

	        stmt = conn.prepareStatement(
	        "insert into house(hname,age,asfeet,nbath,nbed,locid) values(?,?,?,?,?,?)");

	        stmt.setString(1, model.getHname());
	        stmt.setInt(2, model.getAge());
	        stmt.setInt(3, model.getAsfeet());
	        stmt.setInt(4, model.getNbath());
	        stmt.setInt(5, model.getNbed());
	        stmt.setInt(6, model.getLocid());

	        int value = stmt.executeUpdate();

	        return value > 0;

	    } catch (Exception ex) {

	        System.out.println("Error is " + ex);
	        return false;
	    }
	}

	@Override
	public List<LocModel> getAllLocations() {
		try {
			locList =new ArrayList<LocModel>();
			stmt=conn.prepareStatement(" select l.locid, l.locname,c.cityname, s.statename from location l inner join city c on l.cid=c.cid inner join state s on s.sid=c.sid");
			rs=stmt.executeQuery();
			while(rs.next()) {
				LocModel model =new LocModel();
				model.setLocId(rs.getInt(1));
				model.setLocName(rs.getString(2));
				model.setCityName(rs.getString(3));
				model.setStateName(rs.getString(4));
				this.locList.add(model);
				
			}
			return locList;
		}
		catch(Exception ex) {
			System.out.println("Error is" + ex);
			return null;
			
		}
		
	}

	@Override
	public List<HouseModel> getAllHouses() {
		List<HouseModel> houseList = new ArrayList<>();

	    try {

	    	stmt = conn.prepareStatement(
	    		    "select h.hname, h.age, h.asfeet, h.nbath, h.nbed, " +
	    		    "s.statename, c.cityname, l.locname " +
	    		    "from house h " +
	    		    "inner join location l on h.locid = l.locid " +
	    		    "inner join city c on l.cid = c.cid " +
	    		    "inner join state s on c.sid = s.sid"
	    		);
	        

	        rs = stmt.executeQuery();

	        while(rs.next()) {

	            HouseModel model = new HouseModel();

	            model.setHname(rs.getString(1));
	            model.setAge(rs.getInt(2));
	            model.setAsfeet(rs.getInt(3));
	            model.setNbath(rs.getInt(4));
	            model.setNbed(rs.getInt(5));
	            model.setStatename(rs.getString(6));
	            model.setCityName(rs.getString(7));
	            model.setLocationName(rs.getString(8));

	            houseList.add(model);
	        }

	    } catch(Exception ex) {
	        System.out.println("Error is "+ex);
	    }

	    return houseList;
	}

	@Override
	public boolean isDeleteHouse(int hid) {
		 try {

		        stmt = conn.prepareStatement("delete from house where hid=?");

		        stmt.setInt(1, hid);

		        int value = stmt.executeUpdate();

		        return value > 0;

		    }
		    catch(Exception ex) {
		        System.out.println("Error is "+ex);
		        return false;
		    }
	}

	@Override
	public boolean isUpdateHouse(HouseModel model) {
		try {

	        stmt = conn.prepareStatement("update house set hname=? where hid=?");

	        stmt.setString(1, model.getHname());
	        stmt.setInt(2, model.getHid());

	        int value = stmt.executeUpdate();

	        return value > 0;

	    }
	    catch(Exception ex) {
	        System.out.println("Error is "+ex);
	        return false;
	    }
	}

	@Override
	public void countStateWiseHouse() {
		try {

	        stmt = conn.prepareStatement(
	        "select s.statename, count(h.hid) " +
	        "from house h " +
	        "inner join location l on h.locid=l.locid " +
	        "inner join city c on l.cid=c.cid " +
	        "inner join state s on c.sid=s.sid " +
	        "group by s.statename");

	        rs = stmt.executeQuery();

	        while(rs.next()) {

	            System.out.println(rs.getString(1)+"\t"+rs.getInt(2));
	        }

	    } catch(Exception ex) {
	        System.out.println("Error is "+ex);
	    }
		
	}

	@Override
	public void countStateWiseCity() {
		 try {

		        stmt = conn.prepareStatement(
		        "select s.statename, count(c.cid) from city c " +
		        "inner join state s on c.sid=s.sid group by s.statename");

		        rs = stmt.executeQuery();

		        while(rs.next()) {
		            System.out.println(rs.getString(1)+"\t"+rs.getInt(2));
		        }

		    } catch(Exception ex) {
		        System.out.println("Error is "+ex);
		    }
		
	}

	@Override
	public void countStateWiseLocation() {
		 try {

		        stmt = conn.prepareStatement(
		        "select s.statename, count(l.locid) " +
		        "from location l " +
		        "inner join city c on l.cid=c.cid " +
		        "inner join state s on c.sid=s.sid " +
		        "group by s.statename");

		        rs = stmt.executeQuery();

		        while(rs.next()) {
		            System.out.println(rs.getString(1)+"\t"+rs.getInt(2));
		        }

		    } catch(Exception ex) {
		        System.out.println("Error is "+ex);
		    }

		
	}

	@Override
	public void countCityWiseLocation() {
		try {

	        stmt = conn.prepareStatement(
	        "select c.cityname, count(l.locid) " +
	        "from location l inner join city c on l.cid=c.cid " +
	        "group by c.cityname");

	        rs = stmt.executeQuery();

	        while(rs.next()) {
	            System.out.println(rs.getString(1)+"\t"+rs.getInt(2));
	        }

	    } catch(Exception ex) {
	        System.out.println("Error is "+ex);
	    }
		
	}

	@Override
	public void countCityWiseHouse() {
		try {

	        stmt = conn.prepareStatement(
	        "select c.cityname, count(h.hid) " +
	        "from house h " +
	        "inner join location l on h.locid=l.locid " +
	        "inner join city c on l.cid=c.cid " +
	        "group by c.cityname");

	        rs = stmt.executeQuery();

	        while(rs.next()) {
	            System.out.println(rs.getString(1)+"\t"+rs.getInt(2));
	        }

	    } catch(Exception ex) {
	        System.out.println("Error is "+ex);
	    }
		
	}

	@Override
	public void countLocationWiseHouse() {
		 try {

		        stmt = conn.prepareStatement(
		        "select l.locname, count(h.hid) " +
		        "from house h inner join location l on h.locid=l.locid " +
		        "group by l.locname");

		        rs = stmt.executeQuery();

		        while(rs.next()) {
		            System.out.println(rs.getString(1)+"\t"+rs.getInt(2));
		        }

		    } catch(Exception ex) {
		        System.out.println("Error is "+ex);
		    }
		
	}

	@Override
	public void searchHouseByCity(String cityName) {
		try {

	        stmt = conn.prepareStatement(
	        "select h.hname,h.age,h.asfeet from house h " +
	        "inner join location l on h.locid=l.locid " +
	        "inner join city c on l.cid=c.cid where c.cityname=?");

	        stmt.setString(1, cityName);

	        rs = stmt.executeQuery();

	        while(rs.next()) {
	            System.out.println(rs.getString(1)+"\t"+rs.getInt(2)+"\t"+rs.getInt(3));
	        }

	    } catch(Exception ex) {
	        System.out.println("Error is "+ex);
	    }
		
	}

	@Override
	public void searchHouseByLocation(String locationName) {
		try {

	        stmt = conn.prepareStatement(
	        "select h.hname,h.age,h.asfeet from house h " +
	        "inner join location l on h.locid=l.locid where l.locname=?");

	        stmt.setString(1, locationName);

	        rs = stmt.executeQuery();

	        while(rs.next()) {
	            System.out.println(rs.getString(1)+"\t"+rs.getInt(2)+"\t"+rs.getInt(3));
	        }

	    } catch(Exception ex) {
	        System.out.println("Error is "+ex);
	    }
		
	}

	@Override
	public void countAreaWiseHouse() {
		try {

	        stmt = conn.prepareStatement(
	        "select asfeet, count(hid) from house group by asfeet");

	        rs = stmt.executeQuery();

	        while(rs.next()) {
	            System.out.println(rs.getInt(1)+" SqFt\t"+rs.getInt(2));
	        }

	    } catch(Exception ex) {
	        System.out.println("Error is "+ex);
	    }
		
	}

	@Override
	public List<Integer[]> getSquareFeetAreas(int locId) {

	    List<Integer[]> xyList = new ArrayList<>();

	    try {

	        stmt = conn.prepareStatement(
	        "select asfeet, price from house where locid=?");

	        stmt.setInt(1, locId);

	        rs = stmt.executeQuery();

	        while(rs.next()) {

	            Integer arr[] = new Integer[2];

	            arr[0] = rs.getInt("asfeet");   // X
	            arr[1] = rs.getInt("price");    // Y

	            xyList.add(arr);
	        }

	    } 
	    catch(Exception ex) {

	        System.out.println("Error is " + ex);

	    }

	    return xyList;
	}

	@Override
	public int getMinOfXByLocId(int locId) {
		int minX = 0;

	    try {

	        stmt = conn.prepareStatement(
	        "select min(asfeet) from house where locid=?");

	        stmt.setInt(1, locId);

	        rs = stmt.executeQuery();

	        if(rs.next()) {

	            minX = rs.getInt(1);
	        }

	    } 
	    catch(Exception ex) {

	        System.out.println("Error is " + ex);
	    }

	    return minX;

	}

	@Override
	public int getMinOfYByLocId(int locId) {
		 int minY = 0;

		    try {

		        stmt = conn.prepareStatement(
		        "select min(price) from house where locid=?");

		        stmt.setInt(1, locId);

		        rs = stmt.executeQuery();

		        if(rs.next()) {

		            minY = rs.getInt(1);
		        }

		    } 
		    catch(Exception ex) {

		        System.out.println("Error is " + ex);
		    }

		    return minY;
	}
}
