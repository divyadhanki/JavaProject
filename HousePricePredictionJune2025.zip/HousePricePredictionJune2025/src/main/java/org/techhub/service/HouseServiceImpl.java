package org.techhub.service;

import java.util.List;

import org.techhub.model.HouseModel;
import org.techhub.model.LocModel;
import org.techhub.repository.HouseRepository;
import org.techhub.repository.HouseRepositoryImpl;

public class HouseServiceImpl implements HouseService {

    private HouseRepository houseRepo = new HouseRepositoryImpl();

    @Override
    public boolean isAddNewHouse(HouseModel model) {
        return houseRepo.isAddNewHouse(model);
    }

    @Override
    public List<LocModel> getAllLocations() {
        return houseRepo.getAllLocations();
    }

    @Override
    public List<HouseModel> getAllHouses() {
        return houseRepo.getAllHouses();
    }

    @Override
    public boolean isDeleteHouse(int hid) {
        return houseRepo.isDeleteHouse(hid);
    }

    @Override
    public boolean isUpdateHouse(HouseModel model) {
        return houseRepo.isUpdateHouse(model);
    }

    @Override
    public void countStateWiseHouse() {
        houseRepo.countStateWiseHouse();
    }

    @Override
    public void countStateWiseCity() {
        houseRepo.countStateWiseCity();
    }

    @Override
    public void countStateWiseLocation() {
        houseRepo.countStateWiseLocation();
    }

    @Override
    public void countCityWiseLocation() {
        houseRepo.countCityWiseLocation();
    }

    @Override
    public void countCityWiseHouse() {
        houseRepo.countCityWiseHouse();
    }

    @Override
    public void countLocationWiseHouse() {
        houseRepo.countLocationWiseHouse();
    }

    @Override
    public void searchHouseByCity(String cityName) {
        houseRepo.searchHouseByCity(cityName);
    }

    @Override
    public void searchHouseByLocation(String locationName) {
        houseRepo.searchHouseByLocation(locationName);
    }

    @Override
    public void countAreaWiseHouse() {
        houseRepo.countAreaWiseHouse();
    }

    // Linear Regression Calculation
    @Override
    public List<Integer[]> getSquareFeetAreas(int locId) {

    	List<Integer[]> xyList = houseRepo.getSquareFeetAreas(locId);

        System.out.println("X\tY");

        int sumX = 0;
        int sumY = 0;

        for(Integer xy[] : xyList) {
            System.out.println(xy[0] + "\t" + xy[1]);

            sumX += xy[0];
            sumY += xy[1];
        }

        int n = xyList.size();

        double meanX = (double)sumX / n;
        double meanY = (double)sumY / n;

        System.out.println("Mean X : " + meanX);
        System.out.println("Mean Y : " + meanY);

        double devX[] = new double[n];
        double devY[] = new double[n];
        double prodDevXY[] = new double[n];
        double squareDevX[] = new double[n];

        double sumProdDev = 0;
        double sumSquareDevX = 0;

        int index = 0;

        for(Integer xy[] : xyList) {

            devX[index] = xy[0] - meanX;
            devY[index] = xy[1] - meanY;

            prodDevXY[index] = devX[index] * devY[index];
            squareDevX[index] = devX[index] * devX[index];

            sumProdDev += prodDevXY[index];
            sumSquareDevX += squareDevX[index];

            index++;
        }

        double b = sumProdDev / sumSquareDevX;

        double a = meanY - b * meanX;

        System.out.println("Slope (b) = " + b);
        System.out.println("Intercept (a) = " + a);

        // Take user input for prediction
        java.util.Scanner sc = new java.util.Scanner(System.in);

        System.out.println("Enter Square Feet to Predict Price:");
        int userArea = sc.nextInt();

        double predictedPrice = a + b * userArea;

        System.out.println("Predicted Price = " + predictedPrice);

        return xyList;
    }
}