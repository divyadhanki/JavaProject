package org.techhub.service;

import org.techhub.model.LoginModel;
import org.techhub.repository.ValidateUserRepository;
import org.techhub.repository.ValidateUserRepositoryImpl;

public class ValidateUserServiceImpl implements ValidateUserService {
	ValidateUserRepository validateUserRepo = new ValidateUserRepositoryImpl();

	public LoginModel validateUser(LoginModel model) {
		if (model.getUsername().length() == 0 || model.getPassword().length() == 0) {
			return null;

		} else {
			return validateUserRepo.validateUser(model);
		}

	}

}
