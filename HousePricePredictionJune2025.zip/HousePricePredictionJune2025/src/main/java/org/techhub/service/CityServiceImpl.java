package org.techhub.service;

import java.util.List;

import org.techhub.model.CityModel;
import org.techhub.repository.CityRepository;
import org.techhub.repository.CityRepositoryImpl;

public class CityServiceImpl implements CityService{
	
	CityRepository cityRepo =new CityRepositoryImpl();

	@Override
	public boolean isAddNewCity(CityModel model) {
		// TODO Auto-generated method stub
		return cityRepo.isAddNewCity(model);
	}

	@Override
	public List<CityModel> getAllCitiesWithStates() {
		// TODO Auto-generated method stub
		return cityRepo.getAllCitiesWithStates();
	}
	@Override
	public boolean isDeleteCity(int cityId) {

		return cityRepo.isDeleteCity(cityId);

	}
	@Override
	public boolean isUpdateCity(CityModel model) {

		return cityRepo.isUpdateCity(model);

	}

	@Override
	public List<CityModel> getCityListByStateId(int stateId) {

	    return cityRepo.getCityListByStateId(stateId);

	}

}
