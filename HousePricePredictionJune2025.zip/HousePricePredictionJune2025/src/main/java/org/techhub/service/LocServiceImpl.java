package org.techhub.service;

import java.util.List;

import org.techhub.model.LocModel;
import org.techhub.repository.LocRepository;
import org.techhub.repository.LocRepositoryImpl;

public class LocServiceImpl implements LocationService {

	LocRepository locRepo= new LocRepositoryImpl();
	@Override
	public boolean isAddNewLocation(LocModel model) {
		
		return locRepo.isAddNewLocation(model);
	}
	@Override
	public List<LocModel> getLocationByCity(int cityId) {
		
		return locRepo.getLocationByCity(cityId);
	}
	@Override
	public boolean isDeleteLocation(int locId) {
		
		 return locRepo.isDeleteLocation(locId);
	}
	@Override
	public boolean isUpdateLocation(LocModel model) {
		
		return locRepo.isUpdateLocation(model);

	}
	@Override
	public List<LocModel> getLocationByCityId(int cityId) {

	    return locRepo.getLocationByCityId(cityId);

	}

}
