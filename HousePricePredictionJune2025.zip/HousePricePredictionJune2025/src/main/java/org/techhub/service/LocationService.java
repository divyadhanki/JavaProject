package org.techhub.service;

import java.util.List;
import org.techhub.model.LocModel;

public interface LocationService {

    boolean isAddNewLocation(LocModel model);

    List<LocModel> getLocationByCity(int cityId);

    boolean isDeleteLocation(int locId);

    boolean isUpdateLocation(LocModel model);

    List<LocModel> getLocationByCityId(int cityId);  // correct method declaration
}