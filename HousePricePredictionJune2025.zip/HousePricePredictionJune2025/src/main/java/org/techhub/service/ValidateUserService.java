package org.techhub.service;

import org.techhub.model.LoginModel;

public interface ValidateUserService {
	
	public LoginModel validateUser(LoginModel model);

}
