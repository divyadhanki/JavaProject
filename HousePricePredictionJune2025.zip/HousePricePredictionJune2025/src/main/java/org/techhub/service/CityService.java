package org.techhub.service;

import java.util.List;

import org.techhub.model.CityModel;

public interface CityService {
	 boolean isAddNewCity(CityModel model);
	 public List<CityModel> getAllCitiesWithStates();
	 boolean isDeleteCity(int cityId);
	 boolean isUpdateCity(CityModel model);
	 public List<CityModel> getCityListByStateId(int stateId);
	 
}
