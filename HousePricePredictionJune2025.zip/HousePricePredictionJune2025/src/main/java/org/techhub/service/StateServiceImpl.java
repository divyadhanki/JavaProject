package org.techhub.service;

import java.util.List;

import org.techhub.model.StateModel;
import org.techhub.repository.StateRepository;
import org.techhub.repository.StateRepositoryImpl;

public class StateServiceImpl implements StateService {

	StateRepository stateRepo= new StateRepositoryImpl();	
	@Override
	public boolean isAddNewState(StateModel model) {
		
		return stateRepo.isAddState(model);
		
	}
	@Override
	public List<StateModel> getAllState() {
		// TODO Auto-generated method stub
		return stateRepo.getAllState();
	}
	@Override
	public boolean isDeleteState(int stateId) {
		// TODO Auto-generated method stub
		return stateRepo.isDeleteState(stateId);
	}
	@Override
	public boolean isUpdateState(StateModel model) {
		return stateRepo.isUpdateState(model);
	}

}
