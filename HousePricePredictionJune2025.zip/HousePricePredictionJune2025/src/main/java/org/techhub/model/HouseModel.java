package org.techhub.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class HouseModel {

    private int hid;
    private String hname;
    private int age;
    private int asfeet;
    private int nbath;
    private int nbed;
    private int locid;
    
    private String statename;
    private String cityName;
    private String locationName;
}