package org.techhub.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter

public class CityModel extends StateModel {
	private  int cityId;
	private  String cityName;
	

}
