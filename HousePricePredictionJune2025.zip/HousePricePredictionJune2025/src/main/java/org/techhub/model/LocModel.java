package org.techhub.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LocModel extends CityModel{
	private int locId;
	private String LocName;

}
